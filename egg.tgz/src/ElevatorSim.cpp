// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dispatch 4 cars, 8 hours\n", stdout);
  return lionss_run_workload("ElevatorSim");
}
