// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Batch into digests per user\n", stdout);
  return lionss_run_workload("NotifBatch");
}
