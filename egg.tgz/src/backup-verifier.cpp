// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Verify checksums and restore sample\n", stdout);
  return lionss_run_workload("backup-verifier");
}
