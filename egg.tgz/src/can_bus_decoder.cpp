// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Decode 10k frames"); }
int main(){
  announce();
  return lionss_run_workload("can_bus_decoder");
}
