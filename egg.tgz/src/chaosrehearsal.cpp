// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Inject latency, 5 min\n", stdout);
  return lionss_run_workload("chaosrehearsal");
}
