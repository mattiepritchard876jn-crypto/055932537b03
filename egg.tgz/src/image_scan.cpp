// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Scan 3 layers for CVEs\n", stdout);
  return lionss_run_workload("image_scan");
}
