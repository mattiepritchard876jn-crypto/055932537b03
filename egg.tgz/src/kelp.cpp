// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Extract totals and VAT id"); }
int main(){
  announce();
  return lionss_run_workload("kelp");
}
