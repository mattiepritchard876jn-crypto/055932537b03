// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Mine probability per cell"); }
int main(){
  announce();
  return lionss_run_workload("minesweeperprob");
}
