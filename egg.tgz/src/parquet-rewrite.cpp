// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rewrite row groups to 128 MB\n", stdout);
  return lionss_run_workload("parquet-rewrite");
}
