// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Delta-compress replay"); }
int main(){
  announce();
  return lionss_run_workload("replay-pack");
}
