// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Split pacing with elevation"); }
int main(){
  announce();
  return lionss_run_workload("run_pacer");
}
