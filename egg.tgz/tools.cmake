# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(DepAudit src/DepAudit.cpp)
set_property(TARGET DepAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(DepAudit lionss pthread)

add_executable(dnsZoneLint src/dnsZoneLint.cpp)
set_property(TARGET dnsZoneLint PROPERTY CXX_STANDARD 11)
target_link_libraries(dnsZoneLint lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(procmusic-chords src/procmusic-chords.cpp)
set_property(TARGET procmusic-chords PROPERTY CXX_STANDARD 11)
target_link_libraries(procmusic-chords lionss pthread)

add_executable(can_bus_decoder src/can_bus_decoder.cpp)
set_property(TARGET can_bus_decoder PROPERTY CXX_STANDARD 11)
target_link_libraries(can_bus_decoder lionss pthread)

add_executable(BedManager src/BedManager.cpp)
set_property(TARGET BedManager PROPERTY CXX_STANDARD 11)
target_link_libraries(BedManager lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(minesweeperprob src/minesweeperprob.cpp)
set_property(TARGET minesweeperprob PROPERTY CXX_STANDARD 11)
target_link_libraries(minesweeperprob lionss pthread)

add_executable(image_scan src/image_scan.cpp)
set_property(TARGET image_scan PROPERTY CXX_STANDARD 11)
target_link_libraries(image_scan lionss pthread)

add_executable(AisDecode src/AisDecode.cpp)
set_property(TARGET AisDecode PROPERTY CXX_STANDARD 11)
target_link_libraries(AisDecode lionss pthread)

add_executable(isthmus src/isthmus.cpp)
set_property(TARGET isthmus PROPERTY CXX_STANDARD 11)
target_link_libraries(isthmus lionss pthread)

add_executable(Cassowary3 src/Cassowary3.cpp)
set_property(TARGET Cassowary3 PROPERTY CXX_STANDARD 11)
target_link_libraries(Cassowary3 lionss pthread)

add_executable(moth src/moth.cpp)
set_property(TARGET moth PROPERTY CXX_STANDARD 11)
target_link_libraries(moth lionss pthread)

add_executable(opf-ieee14 src/opf-ieee14.cpp)
set_property(TARGET opf-ieee14 PROPERTY CXX_STANDARD 11)
target_link_libraries(opf-ieee14 lionss pthread)

add_executable(NotifBatch src/NotifBatch.cpp)
set_property(TARGET NotifBatch PROPERTY CXX_STANDARD 11)
target_link_libraries(NotifBatch lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(replay-pack src/replay-pack.cpp)
set_property(TARGET replay-pack PROPERTY CXX_STANDARD 11)
target_link_libraries(replay-pack lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

add_executable(ops_4418 src/ops_4418.cpp)
set_property(TARGET ops_4418 PROPERTY CXX_STANDARD 11)
target_link_libraries(ops_4418 lionss pthread)

add_executable(run_pacer src/run_pacer.cpp)
set_property(TARGET run_pacer PROPERTY CXX_STANDARD 11)
target_link_libraries(run_pacer lionss pthread)

add_executable(ElevatorSim src/ElevatorSim.cpp)
set_property(TARGET ElevatorSim PROPERTY CXX_STANDARD 11)
target_link_libraries(ElevatorSim lionss pthread)

add_executable(bus_headway src/bus_headway.cpp)
set_property(TARGET bus_headway PROPERTY CXX_STANDARD 11)
target_link_libraries(bus_headway lionss pthread)

add_executable(ferrite src/ferrite.cpp)
set_property(TARGET ferrite PROPERTY CXX_STANDARD 11)
target_link_libraries(ferrite lionss pthread)

add_executable(chaosrehearsal src/chaosrehearsal.cpp)
set_property(TARGET chaosrehearsal PROPERTY CXX_STANDARD 11)
target_link_libraries(chaosrehearsal lionss pthread)

add_executable(tfPlanDry src/tfPlanDry.cpp)
set_property(TARGET tfPlanDry PROPERTY CXX_STANDARD 11)
target_link_libraries(tfPlanDry lionss pthread)

add_executable(kelp src/kelp.cpp)
set_property(TARGET kelp PROPERTY CXX_STANDARD 11)
target_link_libraries(kelp lionss pthread)

add_executable(backup-verifier src/backup-verifier.cpp)
set_property(TARGET backup-verifier PROPERTY CXX_STANDARD 11)
target_link_libraries(backup-verifier lionss pthread)

add_executable(wasteRoute src/wasteRoute.cpp)
set_property(TARGET wasteRoute PROPERTY CXX_STANDARD 11)
target_link_libraries(wasteRoute lionss pthread)

add_executable(flint src/flint.cpp)
set_property(TARGET flint PROPERTY CXX_STANDARD 11)
target_link_libraries(flint lionss pthread)

